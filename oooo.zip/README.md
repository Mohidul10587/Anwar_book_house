Anwar Book Shop E-Commerce website

milestone -1

- Project setup (front-ent + Back-end)
- Make Home page with Navbar and Footer
- Make The initial dashboard for admin
- Push on Github
- Deploy the site and share the link
- Start the happy journey of our Online book shop

milestone -2

- User(seller) Registration
- Log in a user(seller)
- See All seller in Admin Dashboard
- Delete a seller
- Create a seller dashboard

milestone -3

- Upload a book by seller
- Show all uploaded book on that seller on his Dashboard
- Update a book information
- Delete a book
- Create spacial offer for a book

milestone -4

- Display the all book in the home page
- Pagination the book
- Show the book details
- Search a book by Name of Publication's name of Writer's name
- Create category and sub Category

milestone -5

- Display the all book in the home page
- Pagination the book
- Display the targeted category books in the category page
- Filter the book by published year or with other information
- Show the book details

milestone -6

- Show the related books under the book details page
- Add to cart
- Add to favorite list
- Show the added book in the cart
- Show the favorite book in the favorite list
- Submit the order form cart with payment.

milestone -7

- User registration
- User login
- See all order in dashboard
- Cancel an order
- Return money
- Delivery the order and And shoe the delivered book in the delivered list

milestone -8

- Affiliate program for user
- Show the last sell money of a seller in the admin dashboard
- Payment history to the seller (Total payment , last payment , Due payment ) with date and time
- Give ratings for a product by user
- Give review of a book by user
  milestone -9
- contact page
- About page
- Blog page

## milestone -10

- Update the design of total site for desktop

## milestone -11

- Update the design ot total site for mobile and tablet

milestone -12

- The necessary but not implemented feature will be implement in this milestone
