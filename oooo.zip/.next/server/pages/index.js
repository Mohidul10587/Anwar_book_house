(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 3683:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(1598);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/components/Banner.js






function Banner() {
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        cssEase: "linear"
    };
    const images = [
        {
            id: 3,
            src: "/img1.jpeg"
        },
        {
            id: 1,
            src: "/img2.jpeg"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex gap-4 items-center justify-between overflow-x-hidden rounded-xl -mt-[40px] md:-mt-[52px]",
            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                className: "  overflow-hidden",
                ...settings,
                children: images.map((image)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "  overflow-hidden ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full md:h-[350px] h-44 border relative md:mt-4 mt-8 md:pr-8 overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "  right-4",
                                fill: true,
                                src: image.src,
                                alt: ""
                            })
                        })
                    }, image.id))
            })
        })
    });
}
/* harmony default export */ const components_Banner = (Banner);

// EXTERNAL MODULE: ./src/components/card/productCard.js
var productCard = __webpack_require__(3693);
// EXTERNAL MODULE: ./src/components/layouts/RootLayout.js + 2 modules
var RootLayout = __webpack_require__(6176);
;// CONCATENATED MODULE: ./src/pages/index.js





function Home({ products  }) {
    // const [products, setProducts] = useState([]);
    // console.log(searchQuery);
    const [offerProducts, setOfferProducts] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(false); // Initialize loading as true
    // useEffect(() => {
    //   const fetchData = async () => {
    //     try {
    //       const productsResponse = await fetch(`${url}/api/v1/products`, {
    //         method: "GET",
    //       });
    //       const productsResult = await productsResponse.json();
    //       const productsData = productsResult.data.data;
    //       const offerProductsResponse = await fetch(
    //         `${url}/api/v1/offerProducts`,
    //         {
    //           method: "GET",
    //         }
    //       );
    //       const offerProductsResult = await offerProductsResponse.json();
    //       const offerProductsData = offerProductsResult.data.data;
    //       setProducts(productsData);
    //       setOfferProducts(offerProductsData);
    //       setLoading(false); // Set loading to false after data is fetched
    //     } catch (error) {
    //       console.error(error);
    //       setLoading(false); // Set loading to false in case of an error
    //     }
    //   };
    //   fetchData();
    // }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "sm:py-28 py-20 bg-white",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "w-full max-w-7xl",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_Banner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-8 mx-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-2xl text-green-500",
                            children: "Awesome Offer For You"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-8 mx-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-2xl text-green-500",
                                children: "Our Collection For You"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-2",
                                children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Loading..."
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "grid md:grid-cols-4 lg:grid-cols-6 sm:grid-cols-3 grid-cols-2 gap-2  mb-10 place-content-center",
                                    children: products.map((p)=>/*#__PURE__*/ jsx_runtime_.jsx(productCard/* default */.Z, {
                                            p: p
                                        }, p.id))
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}
Home.getLayout = function getLayout(page) {
    return /*#__PURE__*/ jsx_runtime_.jsx(RootLayout/* default */.Z, {
        children: page
    });
};
async function getStaticProps() {
    try {
        const queryParams = new URLSearchParams({
            search: "",
            genre: "",
            publisher: ""
        });
        const productsResponse = await fetch(`http://test.notebookprokash.com/products?${queryParams}`, {
            method: "GET"
        });
        const productsResult = await productsResponse.json();
        const products = productsResult.products;
        // const offerProductsResponse = await fetch(`${url}/api/v1/offerProducts`, {
        //   method: "GET",
        // });
        // const offerProductsResult = await offerProductsResponse.json();
        // const offerProducts = offerProductsResult.data.data;
        return {
            props: {
                products
            },
            revalidate: 10
        };
    } catch (error) {
        console.error(error);
        return {
            props: {
                products: []
            }
        };
    }
}


/***/ }),

/***/ 1598:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 8866:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gi");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,636,675,176,693], () => (__webpack_exec__(3683)));
module.exports = __webpack_exports__;

})();