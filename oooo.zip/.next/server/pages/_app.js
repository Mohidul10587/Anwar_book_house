(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
;// CONCATENATED MODULE: external "@reduxjs/toolkit/query/react"
const react_namespaceObject = require("@reduxjs/toolkit/query/react");
;// CONCATENATED MODULE: ./src/redux/api/api.js
// Import the RTK Query methods from the React-specific entry point

// Define our single API slice object
const apiSlice = (0,react_namespaceObject.createApi)({
    // The cache reducer expects to be added at `state.api` (already default - this is optional)
    reducerPath: "api",
    // All of our requests will have URLs starting with '/fakeApi'
    baseQuery: (0,react_namespaceObject.fetchBaseQuery)({
        baseUrl: "https://anwar-book-shop.onrender.com/api/v1/products/"
    }),
    // The "endpoints" represent operations and requests for this server
    endpoints: (builder)=>({
            // The `getPosts` endpoint is a "query" operation that returns data
            getNewses: builder.query({
                // The URL for the request is '/fakeApi/posts'
                query: ()=>""
            })
        })
});
// Export the auto-generated hook for the `getPosts` query endpoint
const { useGetNewsesQuery  } = apiSlice;

;// CONCATENATED MODULE: ./src/redux/store.js


/* harmony default export */ const store = ((0,toolkit_namespaceObject.configureStore)({
    reducer: {
        [apiSlice.reducerPath]: apiSlice.reducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(apiSlice.middleware)
}));

// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
;// CONCATENATED MODULE: external "react-redux"
const external_react_redux_namespaceObject = require("react-redux");
;// CONCATENATED MODULE: ./src/pages/_app.js




function App({ Component , pageProps  }) {
    const getLayout = Component.getLayout || ((page)=>page);
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_namespaceObject.Provider, {
        store: store,
        children: getLayout(/*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        }))
    });
}


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5538));
module.exports = __webpack_exports__;

})();