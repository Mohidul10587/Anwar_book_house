"use strict";
exports.id = 176;
exports.ids = [176];
exports.modules = {

/***/ 6176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_RootLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: ./src/components/layouts/Footer.js





const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden sm:block ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex p-3 bg-primary w-full ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-1/2 p-6 text-white border-r",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xl",
                                        children: "Address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-32 h-0.5 bg-red-600 mt-4 mb-5"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Your address will be go here"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-1/2 px-6 pt-6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-gray-400",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-xl text-white",
                                                children: "Explore On"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "w-24 h-0.5 bg-red-600 mt-4 mb-4"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "hover:text-white",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    children: "Home"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "hover:text-white",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/cart",
                                                    children: "Cart"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "hover:text-white",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/service",
                                                    children: "Service"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-white text-xl mt-4",
                                        children: "Join our community"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-32 h-0.5 bg-red-600 mt-4 mb-5"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                    stroke: "currentColor",
                                                    fill: "white",
                                                    strokeWidth: "0",
                                                    viewBox: "0 0 448 512",
                                                    className: " bg-black border-1 border-white mr-2 text-2xl",
                                                    height: "1em",
                                                    width: "1em",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                stroke: "currentColor",
                                                fill: "white",
                                                strokeWidth: "0",
                                                viewBox: "0 0 448 512",
                                                className: " bg-black border-1 border-white mr-2 text-2xl",
                                                height: "1em",
                                                width: "1em",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M400 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm-48.9 158.8c.2 2.8.2 5.7.2 8.5 0 86.7-66 186.6-186.6 186.6-37.2 0-71.7-10.8-100.7-29.4 5.3.6 10.4.8 15.8.8 30.7 0 58.9-10.4 81.4-28-28.8-.6-53-19.5-61.3-45.5 10.1 1.5 19.2 1.5 29.6-1.2-30-6.1-52.5-32.5-52.5-64.4v-.8c8.7 4.9 18.9 7.9 29.6 8.3a65.447 65.447 0 0 1-29.2-54.6c0-12.2 3.2-23.4 8.9-33.1 32.3 39.8 80.8 65.8 135.2 68.6-9.3-44.5 24-80.6 64-80.6 18.9 0 35.9 7.9 47.9 20.7 14.8-2.8 29-8.3 41.6-15.8-4.9 15.2-15.2 28-28.8 36.1 13.2-1.4 26-5.1 37.8-10.2-8.9 13.1-20.1 24.7-32.9 34z"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                stroke: "currentColor",
                                                fill: "white",
                                                strokeWidth: "0",
                                                viewBox: "0 0 448 512",
                                                className: " bg-black border-1 border-white mr-2 text-2xl",
                                                height: "1em",
                                                width: "1em",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M224,202.66A53.34,53.34,0,1,0,277.36,256,53.38,53.38,0,0,0,224,202.66Zm124.71-41a54,54,0,0,0-30.41-30.41c-21-8.29-71-6.43-94.3-6.43s-73.25-1.93-94.31,6.43a54,54,0,0,0-30.41,30.41c-8.28,21-6.43,71.05-6.43,94.33S91,329.26,99.32,350.33a54,54,0,0,0,30.41,30.41c21,8.29,71,6.43,94.31,6.43s73.24,1.93,94.3-6.43a54,54,0,0,0,30.41-30.41c8.35-21,6.43-71.05,6.43-94.33S357.1,182.74,348.75,161.67ZM224,338a82,82,0,1,1,82-82A81.9,81.9,0,0,1,224,338Zm85.38-148.3a19.14,19.14,0,1,1,19.13-19.14A19.1,19.1,0,0,1,309.42,189.74ZM400,32H48A48,48,0,0,0,0,80V432a48,48,0,0,0,48,48H400a48,48,0,0,0,48-48V80A48,48,0,0,0,400,32ZM382.88,322c-1.29,25.63-7.14,48.34-25.85,67s-41.4,24.63-67,25.85c-26.41,1.49-105.59,1.49-132,0-25.63-1.29-48.26-7.15-67-25.85s-24.63-41.42-25.85-67c-1.49-26.42-1.49-105.61,0-132,1.29-25.63,7.07-48.34,25.85-67s41.47-24.56,67-25.78c26.41-1.49,105.59-1.49,132,0,25.63,1.29,48.33,7.15,67,25.85s24.63,41.42,25.85,67.05C384.37,216.44,384.37,295.56,382.88,322Z"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                stroke: "currentColor",
                                                fill: "white",
                                                strokeWidth: "0",
                                                viewBox: "0 0 448 512",
                                                className: " bg-black border-1 border-white mr-2 text-2xl",
                                                height: "1em",
                                                width: "1em",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M448 80v352c0 26.5-21.5 48-48 48H154.4c9.8-16.4 22.4-40 27.4-59.3 3-11.5 15.3-58.4 15.3-58.4 8 15.3 31.4 28.2 56.3 28.2 74.1 0 127.4-68.1 127.4-152.7 0-81.1-66.2-141.8-151.4-141.8-106 0-162.2 71.1-162.2 148.6 0 36 19.2 80.8 49.8 95.1 4.7 2.2 7.1 1.2 8.2-3.3.8-3.4 5-20.1 6.8-27.8.6-2.5.3-4.6-1.7-7-10.1-12.3-18.3-34.9-18.3-56 0-54.2 41-106.6 110.9-106.6 60.3 0 102.6 41.1 102.6 99.9 0 66.4-33.5 112.4-77.2 112.4-24.1 0-42.1-19.9-36.4-44.4 6.9-29.2 20.3-60.7 20.3-81.8 0-53-75.5-45.7-75.5 25 0 21.7 7.3 36.5 7.3 36.5-31.4 132.8-36.1 134.5-29.6 192.6l2.2.8H48c-26.5 0-48-21.5-48-48V80c0-26.5 21.5-48 48-48h352c26.5 0 48 21.5 48 48z"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-primary w-full text-white text-center py-3 border-t",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "\xa9 Copyright By",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "italic",
                                    children: " Md Anwar"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "fixed border-t border-gray-600 sm:hidden bottom-0 h-11 z-30 w-full bg-white px-8  flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineHome, {
                                    className: "text-xl"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/sellers_interaction/cart",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiShoppingCartLine, {
                                    className: "text-xl"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiUserLine, {
                                    className: "text-xl"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiUserLine, {
                                    className: "text-xl"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_Footer = (Footer);

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/gi"
var gi_ = __webpack_require__(8866);
// EXTERNAL MODULE: external "react-icons/fi"
var fi_ = __webpack_require__(2750);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./src/utility/bookCategory.js
var bookCategory = __webpack_require__(981);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
;// CONCATENATED MODULE: ./src/components/layouts/Header.js













const Header = ({ props  })=>{
    // Access the router instance
    const router = (0,router_.useRouter)();
    // Get the current page URL
    const currentUrl = router.asPath;
    (0,external_react_.useEffect)(()=>{
        if (currentUrl != "/search") {
            props.setSearchQuery("");
        }
    }, [
        currentUrl,
        props.props
    ]);
    const [sidebar, setSidebar] = (0,external_react_.useState)(false);
    const handleSidebar = ()=>{
        setSidebar(!sidebar);
    };
    const handleSearch = ()=>{
        // Navigate to the search page with the search text as a query parameter
        router.push(`/search`);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-primary fixed z-10 inset-x-0 items-center px-6 pt-4 pb-4 shadow-lg text-white top-0",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "md:text-2xl flex items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "p-3 text-xl",
                                    onClick: handleSidebar,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaBars, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "cursor-pointer font-bold text-2xl text-white",
                                        children: "Book Shop"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex p-2 bg-white justify-between items-center border border-gray-300 rounded text-black w-[450px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "Search",
                                    className: " w-[380px] outline-none",
                                    value: props.searchQuery,
                                    onChange: (e)=>props.setSearchQuery(e.target.value)
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoSearch, {
                                    className: " right-2 top-2 p-1 rounded bg-primary text-white text-2xl cursor-pointer",
                                    onClick: handleSearch
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex space-x-4 items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/cart",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaShoppingCart, {})
                                            }),
                                            props.cartProductQuantity > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "-mt-4 text-xs  border rounded-full bg-rose-800 w-6 h-6 flex justify-center items-center",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            " ",
                                                            props.cartProductQuantity
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/adminDashboard",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "cursor-pointer",
                                        children: "Admin"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/sellerDashboard",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "cursor-pointer",
                                        children: "Seller"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: sidebar ? "cursor-pointer fixed z-10 inset-0 opacity-70 visible" : "hidden opacity-0",
                        onClick: handleSidebar
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `bg-secondary text-white z-50 duration-500 fixed md:top-[78px] top-0 inset-y-0 py-4  transition-left w-[270px]${sidebar ? " left-0  ease-out" : " -left-full ease-in"}`,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-4 block md:hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex justify-center items-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiBookReader, {
                                            className: "text-5xl"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-center font-bold",
                                        children: " Book Shop"
                                    })
                                ]
                            }),
                            bookCategory/* default.map */.Z.map((category, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    style: {
                                        listStyle: "none"
                                    },
                                    onClick: handleSidebar,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: `/search`,
                                        onClick: ()=>{
                                            props.setGenre(category);
                                        },
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "font-medium inline-flex items-center px-4 py-2 transition w-full hover:bg-white hover:text-gray-800",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiBookReader, {
                                                    className: "mr-3"
                                                }),
                                                category
                                            ]
                                        })
                                    })
                                }, index))
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_Header = (Header);

;// CONCATENATED MODULE: ./src/components/layouts/RootLayout.js
// RootLayout.js




const RootLayout = ({ children  })=>{
    (0,external_react_.useEffect)(()=>{
        const products = JSON.parse(localStorage.getItem("cart"));
        const totalQuantity = products?.reduce((total, product)=>total + product.quantity, 0);
        setCartProductQuantity(totalQuantity);
    });
    const [genre, setGenre] = (0,external_react_.useState)("");
    const [searchQuery, setSearchQuery] = (0,external_react_.useState)("");
    const [cartProductQuantity, setCartProductQuantity] = (0,external_react_.useState)(0);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Header, {
                props: {
                    setGenre,
                    setSearchQuery,
                    searchQuery,
                    cartProductQuantity
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: /*#__PURE__*/ (0,external_react_.cloneElement)(children, {
                    genre,
                    setGenre,
                    searchQuery,
                    cartProductQuantity,
                    setCartProductQuantity
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Footer, {})
        ]
    });
};
/* harmony default export */ const layouts_RootLayout = (RootLayout);


/***/ }),

/***/ 981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const genres = [
    "ধর্মীয়",
    "উপন্যাস",
    "কবিতা",
    "স্মৃতিরচিত্র",
    "গল্প",
    "প্রবন্ধ",
    "বিজ্ঞান গবেষণা",
    "ইতিহাস",
    "রোমান্টিক",
    "ফ্যান্টাসি",
    "স্বাস্থ্য ও কর্মসংস্কার",
    "কৃষি ও গার্ডেনিং",
    "কোমিক্স ও গ্রাফিক নভেল",
    "শিক্ষা"
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (genres);


/***/ })

};
;