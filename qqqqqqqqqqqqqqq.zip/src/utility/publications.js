const publications = [
  "Penguin Random House",
  "HarperCollins Publishers",
  "Simon & Schuster",
  "Hachette Livre",
  "Macmillan Publishers",
  "Wiley",
  "Oxford University Press",
  "Pearson Education",
  "Scholastic Corporation",
  "Houghton Mifflin Harcourt",
  "Bloomsbury Publishing",
  "Cambridge University Press",
  "Pan Macmillan",
  "Allen & Unwin",
  "John Wiley & Sons",
];
export default publications;
