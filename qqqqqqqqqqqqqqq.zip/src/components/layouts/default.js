const DefaultLayout = ({ children }) => (
  <div>
    <div>{children}</div>
  </div>
);

export default DefaultLayout;
